Pre-Warp test version WARS!  8.4.99
All Rights by CLAW-Software

Features at the moment

- good pathfinding
- 800*600 with 16 bit colors
- People collect wood and food to build new people and homes

Under construction

- market places, where people can trade
- new resources like water, stone and gold

Requirements:
- DirectX 3.0

Controls:
- Scrolling : right mouse button, cursor keys
- Exit : ESC



Please copy this version to all your friends and tell us what you think.
---------
Leadprogrammer Clemens Lode, also known as Claw Ghoul
clemens.lode@allgaeu.org
www.clawsoftware.de
