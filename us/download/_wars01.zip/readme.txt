Pre-Warp test version 0.1 WARS!  5/6/99

All Rights by CLAW-Software


0.07:
New features

- good pathfinding
- 800*600 with 16 bit colors
- People collect wood and food to build new people and homes


0.1:
New features

- better AI in finding the place of new houses
- menu system
- first test of a camera window
- fixed some graphic bux
- SPEED INCREASE!


Under construction

- market places, where people can trade
- new resources like water, stone and gold
- coast, water
- find terrain-editor bux
- config file

Known bugs

- terrain/-editor (click one time right mouse button)
- coast
- hang up-s after some time (just press ALT-F4 then)
- screenshot don't work
- some menu items aren't implemented yet


Requirements:
- DirectX 3.0

Controls:
- Scrolling : mouse cursor, cursor keys
- F9 : Reveal map


Please copy this version to all your friends and tell us what you think.
---------
Leadprogrammer Clemens Lode, also known as Claw Ghoul
ghoul@clawsoftware.de
www.clawsoftware.de
